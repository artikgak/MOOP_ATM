#ifndef ACCOUNTMENU_H
#define ACCOUNTMENU_H


class AccountMenu
{
public:
    AccountMenu();
};

#endif // ACCOUNTMENU_H
