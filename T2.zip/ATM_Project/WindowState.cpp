#include "WindowState.h"
#include "mainwindow.h"


Ui::MainWindow *WindowState::getUi() {
    return context->ui;
}
