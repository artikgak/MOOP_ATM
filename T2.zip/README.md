# MOOP_ATM
Project for the MOOP course at NaUKMA, 3rd year.
